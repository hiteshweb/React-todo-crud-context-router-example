const About = () => {
    return (
        <>
            About us
        </>
    );
};

export default About;