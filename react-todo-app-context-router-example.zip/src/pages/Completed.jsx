const Completed = () => {
    return (
        <>
            Completed
        </>
    );
};

export default Completed;