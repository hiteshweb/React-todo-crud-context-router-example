import AddTodo from "../components/AddTodo";
import TodoList from "../components/TodoList";

const Home = () => {
    return (
        <>
        <AddTodo />
        <br/>
        <TodoList />
        </>
    );
};

export default Home;